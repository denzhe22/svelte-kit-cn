import{p as a}from"./BCiPhWVJ.js";a();
